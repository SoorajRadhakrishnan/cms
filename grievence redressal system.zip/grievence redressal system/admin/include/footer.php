	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2019 CMS </b> All rights reserved.
		</div>
	</div>